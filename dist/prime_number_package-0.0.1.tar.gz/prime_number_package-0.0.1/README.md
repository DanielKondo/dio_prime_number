# prime_number
Description. The package prime_number_package is used to check if a number is a prime number

# Usage

```python
from prime_number_package import is_prime
is_prime.is_prime()
```

# Author
Daniel Kondo